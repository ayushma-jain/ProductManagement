<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Order;
use App\ParentChildMapping;
use DB;

class ProductController extends Controller
{
	
	/**
     * @Function: getProductDetailView()
     * @Description: function is used to get view page
     * @date: 11/May/2021
     * @lastModified: 
    */
    public function getProductDetailView(){
		$data = array();
		$data['productList'] = Product::where(['product_status' => 'Active'])->get()->toArray();
		
		$data['mergeProductList'] = Product::where(['product_status' => 'Active','product_type'=>NULL])->select('product_sku','title')->get()->toArray();
		
		
		$data['orderReportList']  = DB::table('order_details As O')
			->leftjoin('product_details As P','P.product_sku','=','O.product_sku')
			->select('P.*',DB::raw('sum(O.quantity) as totalQuantity'),DB::raw('sum(O.profit) as totalProfit'))->orderBy('P.product_sku')
			->take(5)->groupBy('P.product_sku')->get()->toArray();
		
		return view('welcome', $data);
		
	}
	
	/**
     * @Function: addNewProduct()
     * @Description: function is used to add new product.
     * @date: 11/May/2021
     * @lastModified: 
    */
	public function addNewProduct(Request $request){
		$productTitle = isset($request->productTitle) ? $request->productTitle : '';
		$quantity = isset($request->quantity) ? $request->quantity : 0;
		$sellingPrice = isset($request->sellingPrice) ? $request->sellingPrice : 0;
		$buyingPrice = isset($request->buyingPrice) ? $request->buyingPrice : 0;
		
		$newProduct = new Product;
		$newProduct->title = $productTitle;
		$newProduct->total_quantity = $quantity;
		$newProduct->available_quantity = $quantity;
		$newProduct->sold_quantity = 0;
		$newProduct->selling_price = $sellingPrice;
		$newProduct->buying_price = $buyingPrice;
		if($newProduct->save()){
			return redirect()->back()->with('success', "Product Added Successfully!!");
		}else{
			return redirect()->back()->with('error', "Something went wrong, Try again later!!");
		}
	
	}
	
	/**
     * @Function: buyProduct()
     * @Description: function is used to to buy Product.
     * @date: 11/May/2021
     * @lastModified: 
    */
	public function buyProduct(Request $request)
	{
		$response = ['status' => 0 , 'message' => 'Required Parameters Missing!!'];
		$productId = isset($request->productId) ? $request->productId : '';
		$productQuantity = isset($request->productQuantity) ? $request->productQuantity : 0;
		if(!empty($productQuantity) && !empty($productId)){
			//Query to check product is exist or not.
			
			$productDetails = Product::where(['product_sku' => $productId])->select('available_quantity','sold_quantity','selling_price','buying_price')->get()->first()->toArray();
			if(!empty($productDetails)){
				$availableQuantity = isset($productDetails['available_quantity']) ? $productDetails['available_quantity'] : 0;
				$soldQuantity = isset($productDetails['sold_quantity']) ? $productDetails['sold_quantity'] : 0;
				$sellingPrice = isset($productDetails['selling_price']) ? $productDetails['selling_price'] : 0;
				$buyingPrice = isset($productDetails['buying_price']) ? $productDetails['buying_price'] : 0;
				if($availableQuantity >= $productQuantity){
					$order = new Order;
					$order->product_sku = $productId;
					$order->quantity = $productQuantity;
					$order->price = $sellingPrice;
					$order->profit = $sellingPrice-$buyingPrice;
					if($order->save()){
						$newAvailableQuantity = $availableQuantity-$productQuantity;
						$newSoldQuantity = $soldQuantity+$productQuantity;
						Product::where(['product_sku' => $productId])->update(['available_quantity'=>$newAvailableQuantity,'sold_quantity'=>$newSoldQuantity]);
						$response = ['status' => 1 , 'message' => 'Product ordered successfully!!'];
					}
				}else{
					$response = ['status' => 0 , 'message' => 'Quantity is not available!!'];
				}
				
				
			}else{
				$response = ['status' => 0 , 'message' => 'Product is not available!!'];
			}
			
		}else{
			$response = ['status' => 0 , 'message' => 'Something went wrong, Try again later!!'];
		}
		return $response;
	}
	
	public function getReports(Request $request){
		
		$reportTypeFilter = isset($request->reportTypeFilter) ? $request->reportTypeFilter : '';
		$productTypeFilter = isset($request->productTypeFilter) ? $request->productTypeFilter : '';
		if($reportTypeFilter == 'Profit'){
			$orderBy ='totalProfit';
		}elseif($reportTypeFilter == 'Quantity'){
			$orderBy ='totalQuantity';
		}else{
			$orderBy ='P.product_sku';
		}
		$orderReportList = array();
		if($productTypeFilter == 'Parent'){
			
			$orderReportList  = DB::table('order_details As O')->where(['P.product_type' => 'Parent'])
				->leftjoin('product_details As P','P.product_sku','=','O.product_sku')
				->join(DB::raw("(SELECT DB::raw('sum(O.quantity) as childTotalQuantity'), DB::raw('sum(O.profit) as childTotalProfit')
					From parent_child_mapping M  Group by P.product_sku"),function($join){
						$join->on('M.child_sku', '=', 'P.product_sku');
					})
				->select('P.*',DB::raw('sum(O.quantity) as totalQuantity'),DB::raw('sum(O.profit) as totalProfit'))->orderBy($orderBy,'desc')
			->take(5)->groupBy('P.product_sku')->get()->toArray();
			
		}else{
			$orderReportList  = DB::table('order_details As O')
				->leftjoin('product_details As P','P.product_sku','=','O.product_sku')
				->select('P.*',DB::raw('sum(O.quantity) as totalQuantity'),DB::raw('sum(O.profit) as totalProfit'))->orderBy($orderBy,'desc')
			->take(5)->groupBy('P.product_sku')->get()->toArray();
		}
		
		$returnHTML = view('product-report-view')->with(['orderReportList' => $orderReportList])->render();
		return $returnHTML;
	}
	
	
	public function mergeProducts(Request $request){
		$response = ['status' => 0 , 'message' => 'Required Parameters Missing!!'];
		$parentProductId = isset($request->parentProductId) ? $request->parentProductId : '';
		$childProductId = isset($request->childProductId) ? $request->childProductId : '';
		if(!empty($parentProductId) && !empty($childProductId)){
			if($parentProductId != $childProductId){
				$parentChildMapping = new ParentChildMapping;
				$parentChildMapping->parent_sku = $parentProductId;
				$parentChildMapping->child_sku = $childProductId;
				if($parentChildMapping->save()){
					Product::where(['product_sku' => $parentProductId])->update(['product_type'=>'Parent']);
					Product::where(['product_sku' => $childProductId])->update(['product_type'=>'Child']);
					$response = ['status' => 1 , 'message' => 'Product Merge successfully !!'];
				}else{
					$response = ['status' => 0 , 'message' => 'Parent and child Products are not same !!'];
				}
				
			}else{
				$response = ['status' => 0 , 'message' => 'Something went wrong, Try again later!!'];
			}
			
		}
		return $response;
	}
}

