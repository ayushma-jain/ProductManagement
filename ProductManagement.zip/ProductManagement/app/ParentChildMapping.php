<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParentChildMapping extends Model
{
	protected $table = 'parent_child_mapping';
}
