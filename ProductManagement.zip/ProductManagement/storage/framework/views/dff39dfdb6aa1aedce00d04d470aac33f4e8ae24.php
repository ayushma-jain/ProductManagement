<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th>S.No.</th>
			<th>Product Name</th>
			<th>Buying Price</th>
			<th>Selling Price</th>
			<th>Total Quantity</th>
			<th>Total Available Quantity</th>
			<th>Total Sold Quantity</th>
			<th>Total Profit</th>
		</tr>
	</thead>
	<tbody>
		<?php if(isset($orderReportList) && count($orderReportList) > 0): ?>
			<?php $i=1; ?>
		
			<?php $__currentLoopData = $orderReportList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($i); ?></td>
					<td><?php echo e(isset($orderItem->title) ? $orderItem->title: '--'); ?></td>
					<td><?php echo e(isset($orderItem->buying_price) ? $orderItem->buying_price: 0); ?></td>
					<td><?php echo e(isset($orderItem->selling_price) ? $orderItem->selling_price: 0); ?></td>
					<td><?php echo e(isset($orderItem->total_quantity) ? $orderItem->total_quantity: ''); ?></td>
					<td><?php echo e(isset($orderItem->available_quantity) ? $orderItem->available_quantity: ''); ?></td>
					<td><?php echo e(isset($orderItem->totalQuantity) ? $orderItem->totalQuantity: ''); ?></td>
					<td><?php echo e(isset($orderItem->totalProfit) ? $orderItem->totalProfit: ''); ?></td>
				</tr>
				<?php $i++; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php else: ?>
			<tr>
				<td colspan="8">No Products Found</td>
			</tr>
		<?php endif; ?>
	</tbody>
</table><?php /**PATH E:\AyushmaPersonal\Laravel\ProductManagement\resources\views/product-report-view.blade.php ENDPATH**/ ?>