<html>
	<head>
		<title>Bootstrap Example</title>
		<meta charset="utf-8">
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
		<input type="hidden" name="hf_base_url" id="hf_base_url" value="<?php echo e(url('/')); ?>">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous"></script>
	</head>
	<body>
		<div class="m-5">
			<div class="row">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							Add Product
						</div>
						<div class="card-body">
							<?php if(session('success')): ?>
								<div class="alert alert-success">
									<?php echo e(session('success')); ?>

								</div>
							<?php endif; ?>

							<?php if(session('error')): ?>
								<div class="alert alert-danger">
									<?php echo e(session('error')); ?>

								</div>
							<?php endif; ?>
							
							
							<form method="post" action="<?php echo e(route('add-product')); ?>"   >
								<input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>" />
								
								<div class="row">
									<div class="col-3">
										<div class="form-group">
											<label for="productTitle">Product Title</label>
											<input type="text" class="form-control" id="productTitle" name="productTitle" placeholder="Product Title" autocomplete="off" required>
										</div>
									</div>
									<div class="col-3">
										<div class="form-group">
											<label for="quantity">Quantity</label>
											<input type="text" class="form-control" id="quantity" name="quantity" placeholder="Quantity" autocomplete="off" required>
										</div>
									</div>
									<div class="col-3">
										<div class="form-group">
											<label for="sellingPrice">Selling Price</label>
											<input type="text" class="form-control" id="sellingPrice" name="sellingPrice" placeholder="Selling Price" autocomplete="off" required>
										</div>
									</div>
									<div class="col-3">
										<div class="form-group">
											<label for="buyingPrice">Buying Price</label>
											<input type="text" class="form-control" id="buyingPrice" name="buyingPrice" placeholder="Buying Price" autocomplete="off" required>
										</div>
									</div>
									<div class="col-12 text-right">
										<button type="submit" class="btn btn-success">Add</button>
									</div>
								</div>
								
							</form>
						</div>
					</div>
				</div>
			</div>
			<div class="row mt-4">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							Product List
						</div>
						<div class="card-body">
							<table class="table table-bordered table-striped">
								<thead>
									<tr>
										<th>S.No.</th>
										<th>Product Name</th>
										<th>Total Quantity</th>
										<th>Available Quantity</th>
										<th>Selling Price</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php if(isset($productList) && count($productList) > 0): ?>
										<?php $i=1; ?>
									
										<?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($i); ?></td>
												<td><?php echo e(isset($product['title']) ? $product['title']: '--'); ?></td>
												<td><?php echo e(isset($product['total_quantity']) ? $product['total_quantity']: 0); ?></td>
												<td><?php echo e(isset($product['available_quantity']) ? $product['available_quantity']: 0); ?></td>
												<td><?php echo e(isset($product['selling_price']) ? $product['selling_price']: ''); ?></td>
												<td>
													<input type="number" min="0" max="<?php echo e($product['available_quantity']); ?>" class="soldQuantity_<?php echo e($product['product_sku']); ?>">&nbsp;&nbsp;
													<input type="button" class="btn btn-sm btn-primary buyProduct" value="buy" rel="<?php echo e($product['product_sku']); ?>"/>
												</td>
											</tr>
											<?php $i++; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<tr>
											<td colspan="6">No Products Found</td>
										</tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row mt-4">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							Merge Products
						</div>
						<div class="card-body">
							<div class="row">
								<div class="col-4">
									<select class="form-control" id="parentProductId">
										<option value="">Select Parent Product</option>
										<?php if(isset($mergeProductList) && count($mergeProductList) > 0): ?>
											<?php $__currentLoopData = $mergeProductList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($product['product_sku']); ?>"><?php echo e($product['title']); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									
									</select>
								</div>
								<div class="col-4">
									<select class="form-control" id="childProductId">
										<option value="">Select Child Product</option>
										<?php if(isset($mergeProductList) && count($mergeProductList) > 0): ?>
											<?php $__currentLoopData = $mergeProductList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($product['product_sku']); ?>"><?php echo e($product['title']); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									
									</select>
								</div>
								<div class="col-4">
									<input type="button" class="btn btn-success" value="Merge Product" id="mergeProduct"/>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
						<div class="row mt-4">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							Reports
						</div>
						<div class="card-body">
							<div class="row">
								<div class="col-3">
									<select class="form-control" id="reportTypeFilter">
										<option value="">Report</option>
										<option value="Profit">Profit wise</option>
										<option value="Quantity">Quantity wise</option>
										
									</select>
								</div>
								<div class="col-3">
									<select class="form-control" id="productTypeFilter">
										<option value="">Select Parent Product</option>
										<option value="All">All Products</option>
										<option value="Parent">Parent Products</option>
		
									</select>
								</div>
								<div class="col-4">
									<input type="button" class="btn btn-success" value="Search" id="filterReport"/>
								</div>
							</div>
							<div class="row mt-4">
								<div class="col-12" id="reportTable">
									<?php echo $__env->make('product-report-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			
		</div>
	</body>
</html>
<script>

$(function(){
	
	$(document).on('click','.buyProduct',function(){
		
		var productId= $(this).attr('rel');
		var productQuantity  = $('.soldQuantity_'+productId).val();
		var parameterArray = {'productId' : productId,'productQuantity':productQuantity};
		$.ajax({
			url: $('#hf_base_url').val()+'/buy-product',
			data: parameterArray,
			type: 'POST',
			headers: { 'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')},
			dataType: 'JSON',
			success:function(response) {
				if(response.status == 1){
					swal("Success", response.message, "success");
					setTimeout(function(){
						window.location.href=window.location.href;
					}, 1000);
				}else{
					swal("Warning", response.message, "error");
				}
			}
			
		});
	});
	
	$(document).on('click','#filterReport',function(){
		var reportTypeFilter= $('#reportTypeFilter').val();
		var productTypeFilter= $('#productTypeFilter').val();
		
		var parameterArray = {'reportTypeFilter' : reportTypeFilter,'productTypeFilter':productTypeFilter};
		
		$.ajax({
			url: $('#hf_base_url').val()+'/get-reports',
			data: parameterArray,
			type: 'POST',
			headers: { 'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')},
			dataType: 'HTML',
			success:function(response) {
				$('#reportTable').html(response);
			}
			
		});
	})
	
	$(document).on('click','#mergeProduct',function(){
		var parentProductId= $('#parentProductId').val();
		var childProductId= $('#childProductId').val();
		
		var parameterArray = {'parentProductId' : parentProductId,'childProductId':childProductId};
		
		$.ajax({
			url: $('#hf_base_url').val()+'/merge-products',
			data: parameterArray,
			type: 'POST',
			headers: { 'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')},
			dataType: 'HTML',
			success:function(response) {
				if(response.status == 1){
					swal("Success", response.message, "success");
					setTimeout(function(){
						window.location.href=window.location.href;
					}, 1000);
				}else{
					swal("Warning", response.message, "error");
				}
			}
			
		});
	})
	
	$(".alert-success").fadeTo(2000, 800).slideUp(800, function(){
		$(".alert-success").slideUp(500);
	});

	$(".alert-danger").fadeTo(2000, 800).slideUp(800, function(){
		$(".alert-danger").slideUp(500);
	});
});




</script><?php /**PATH E:\AyushmaPersonal\Laravel\ProductManagement\resources\views/welcome.blade.php ENDPATH**/ ?>