<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [
    'uses' => 'ProductController@getProductDetailView',
	'as'   => 'add-product'
]);
Route::post('/add-product', [
	'uses' => 'ProductController@addNewProduct',
	'as'   => 'add-product'
]);
Route::post('/buy-product', [
	'uses' => 'ProductController@buyProduct',
	'as'   => 'buy-product'
]);
Route::post('/get-reports', [
	'uses' => 'ProductController@getReports',
	'as'   => 'get-reports'
]);
Route::post('/merge-products', [
	'uses' => 'ProductController@mergeProducts',
	'as'   => 'merge-products'
]);