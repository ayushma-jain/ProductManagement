-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2021 at 07:09 AM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_id` int(11) NOT NULL,
  `product_sku` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `profit` double DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Consider created_at time as order_date'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`order_id`, `product_sku`, `quantity`, `price`, `profit`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 1000, 200, '2021-05-11 16:35:16', '2021-05-11 16:35:16'),
(2, 1, 2, 1000, 200, '2021-05-11 16:35:26', '2021-05-11 16:35:26'),
(3, 2, 1, 500, 250, '2021-05-11 17:36:31', '2021-05-11 17:36:31'),
(4, 2, 2, 500, 250, '2021-05-11 17:46:49', '2021-05-11 17:46:49'),
(5, 3, 3, 1200, 200, '2021-05-12 03:57:28', '2021-05-12 03:57:28'),
(6, 6, 1, 300, 100, '2021-05-12 04:00:14', '2021-05-12 04:00:14'),
(7, 6, 1, 300, 100, '2021-05-12 04:00:25', '2021-05-12 04:00:25'),
(8, 5, 3, 2000, 500, '2021-05-12 04:00:33', '2021-05-12 04:00:33'),
(9, 4, 1, 500, 150, '2021-05-12 04:00:42', '2021-05-12 04:00:42'),
(10, 7, 1, 50, 15, '2021-05-12 04:23:59', '2021-05-12 04:23:59');

-- --------------------------------------------------------

--
-- Table structure for table `parent_child_mapping`
--

CREATE TABLE `parent_child_mapping` (
  `id` int(11) NOT NULL,
  `parent_sku` int(11) NOT NULL,
  `child_sku` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_child_mapping`
--

INSERT INTO `parent_child_mapping` (`id`, `parent_sku`, `child_sku`, `created_at`, `updated_at`) VALUES
(1, 2, 7, '2021-05-11 22:50:00', '2021-05-11 22:50:00');

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `product_sku` int(11) NOT NULL,
  `title` varchar(300) DEFAULT NULL,
  `total_quantity` bigint(20) DEFAULT NULL,
  `available_quantity` bigint(20) DEFAULT NULL,
  `sold_quantity` bigint(20) DEFAULT NULL,
  `selling_price` double DEFAULT NULL,
  `buying_price` double DEFAULT NULL,
  `product_type` enum('Parent','Child') DEFAULT NULL,
  `product_status` enum('Active','Deleted') NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`product_sku`, `title`, `total_quantity`, `available_quantity`, `sold_quantity`, `selling_price`, `buying_price`, `product_type`, `product_status`, `created_at`, `updated_at`) VALUES
(1, 'T-shirt', 12, 8, 4, 1000, 800, NULL, 'Active', '2021-05-11 15:42:11', '2021-05-11 16:35:26'),
(2, 'Footwear', 20, 17, 3, 500, 250, 'Parent', 'Active', '2021-05-11 15:55:05', '2021-05-12 04:20:01'),
(3, 'Salwar suit', 50, 47, 3, 1200, 1000, NULL, 'Active', '2021-05-12 03:53:01', '2021-05-12 03:57:28'),
(4, 'Toys', 30, 29, 1, 500, 350, NULL, 'Active', '2021-05-12 03:58:44', '2021-05-12 04:00:42'),
(5, 'Western wear', 100, 97, 3, 2000, 1500, NULL, 'Active', '2021-05-12 03:59:30', '2021-05-12 04:00:33'),
(6, 'Sunglasses', 500, 498, 2, 300, 200, NULL, 'Active', '2021-05-12 04:00:06', '2021-05-12 04:00:25'),
(7, 'Socks', 20, 19, 1, 50, 35, 'Child', 'Active', '2021-05-12 04:03:29', '2021-05-12 04:23:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `parent_child_mapping`
--
ALTER TABLE `parent_child_mapping`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_details`
--
ALTER TABLE `product_details`
  ADD PRIMARY KEY (`product_sku`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `parent_child_mapping`
--
ALTER TABLE `parent_child_mapping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product_details`
--
ALTER TABLE `product_details`
  MODIFY `product_sku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
